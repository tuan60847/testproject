<style>
    .tesstEmail {
        width: 100%;
        padding: 20px;
        text-align: center;
    }
</style>
<div class="tesstEmail">
    <h2>Hi {{ $chukhachsan->HoTen }}</h2>
    <p>Sure! Here's a thank you message in English for using our services:</P>
    <p> "Thank you for choosing our services! We sincerely appreciate your trust and support. If you have any further
        questions or need assistance, please don't hesitate to reach out to us. We look forward to serving you again in
        the future. Have a wonderful day!"</p>
    <p> Feel free to customize this message to fit your specific context.</p>
</div>
