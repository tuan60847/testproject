<!DOCTYPE html>
<html>

<head>
    <title>View Image</title>
</head>

<body>
    <img src="<?php echo e(asset('storage/image/loaiphong/' . $filename)); ?>" alt="Hình ảnh">
</body>

</html><?php /**PATH C:\xampp\htdocs\testproject\resources\views/hinhtest.blade.php ENDPATH**/ ?>