<?php $__env->startSection('content'); ?>
<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Loại phòng</h1>
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Loại phòng
                <a <?php if(Session::has('cksData')): ?> href="<?php echo e(url('/adminKS/loaiphong/findbyKS/'.Session::get('cksData')->ADMINKS.'/create')); ?>" <?php endif; ?> class="float-right btn-primary btn-sm">Thêm mới</a>
            </h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Mã loại</th>
                            <th>Tên loại phòng</th>
                            <th>Máy lạnh</th>
                            <th>Số giường</th>
                            <th>Giá phòng</th>
                            <th>Số lượng</th>
                            <th>Hình ảnh</th>
                            <th>Thao tác</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th>Mã loại</th>
                            <th>Tên loại phòng</th>
                            <th>Máy lạnh</th>
                            <th>Số giường</th>
                            <th>Giá phòng</th>
                            <th>Số lượng</th>
                            <th>Hình ảnh</th>
                            <th>Thao tác</th>
                        </tr>
                    </tfoot>
                    <tbody>

                        <?php if($loaiphong): ?>
                        <?php $__currentLoopData = $loaiphong; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($d->UIDLoaiPhong); ?></td>
                            <td><?php echo e($d->TenLoaiPhong); ?></td>
                            <td><?php echo e($d->isMayLanh); ?></td>
                            <td><?php echo e($d->soGiuong); ?></td>
                            <td><?php echo e($d->Gia); ?></td>
                            <td><?php echo e($d->soLuongPhong); ?></td>
                            <td><?php echo e(count($d->hinhanhloaiphongs)); ?></td>
                            <td>
                                <a href="<?php echo e(url('adminKS/loaiphong/findbyKS/'.$d->UIDLoaiPhong.'/show')); ?>" class="btn btn-info btn-sm"><i class="fa fa-eye"></i></a>
                                <a href="<?php echo e(url('adminKS/loaiphong/findbyKS/'.$d->UIDLoaiPhong.'/edit')); ?>" class="btn btn-success btn-sm"><i class="fa fa-edit"></i></a>

                                <!-- <a onclick="confirm('Bạn có chắc muốn xóa loại phòng này?')" <?php if(Session::has('cksData')): ?> href="<?php echo e(url('adminKS/loaiphong/findbyKS/'.Session::get('cksData')->ADMINKS.'/delete/'.$d->UIDLoaiPhong)); ?>" <?php endif; ?> class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></a> -->
                                <a onclick="confirm('Bạn có chắc muốn xóa loại phòng này?')" href="<?php echo e(url('adminKS/loaiphong/findbyKS/'.$d->UIDLoaiPhong.'/delete')); ?>" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>

<!-- /.container-fluid -->
<?php $__env->startSection('script'); ?>
<!-- Custom styles for this page -->
<link href="<?php echo e(asset('vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
<!-- Page level plugins -->
<script src="<?php echo e(asset('vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>

<!-- Page level custom scripts -->
<script src="<?php echo e(asset('js/demo/datatables-demo.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutKS', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\testproject\resources\views/loaiphong/index.blade.php ENDPATH**/ ?>