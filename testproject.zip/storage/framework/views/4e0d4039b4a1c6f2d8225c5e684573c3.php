
<?php $__env->startSection('content'); ?>
<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Cập nhật đơn đặt phòng</h6>
        </div>
        <div class="card-body">
            <?php if($errors->any()): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p class="text-danger"><?php echo e($error); ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <?php if(Session::has('success')): ?>
            <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
            <?php endif; ?>
            <div class="table-responsive">
                <form action="<?php echo e(url('adminKS/dondatphong/'.$dondatphong->UIDDatPhong)); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('put'); ?>
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <tr>
                            <th>Mã đặt phòng</th>
                            <td><?php echo e(Str::limit($dondatphong->UIDDatPhong)); ?></td>
                        </tr>
                        <tr>
                            <th>Email</th>
                            <td><?php echo e($dondatphong->EmailKH); ?></td>
                        </tr>
                        <tr>
                            <th>Ngày đặt phòng</th>
                            <td><?php echo e($dondatphong->NgayDatPhong); ?></td>
                        </tr>

                        <tr>
                            <th>Tiền cọc</th>
                            <td><?php echo e($dondatphong->TienCoc); ?></td>
                        </tr>
                        <tr>
                            <th>Tổng tiền</th>
                            <td><?php echo e(number_format($dondatphong->tongtien, 0, ',', '.')); ?></td>
                        </tr>
                        <tr>
                            <th>Trạng thái</th>
                            <td>
                                <select name="isChecked" aria-controls="dataTable" class="custom-select custom-select-sm form-control form-control-sm">
                                    <?php if($dondatphong->isChecked==0): ?>
                                    <option value="0" selected>Chưa xác nhận</option>
                                    <option value="1">Xác nhận</option>
                                    <option value="6">Hủy đơn đặt phòng</option>
                                    <?php elseif($dondatphong->isChecked == 1): ?>
                                    <option value="1" selected>Xác nhận</option>
                                    <option value="3">Check In</option>
                                    <?php elseif($dondatphong->isChecked == 0): ?>
                                    <option value="0">Chưa xác nhận</option>
                                    <option value="1">Xác Nhận</option>
                                    <option value="6">Hủy đơn đặt phòng</option>
                                    <?php elseif($dondatphong->isChecked == 3): ?>
                                    <option value="3" selected>Check In</option>
                                    <option value="5">Check out</option>
                                    <?php elseif($dondatphong->isChecked == 5): ?>
                                    <option value="5" selected>Check out</option>
                                    <?php elseif($dondatphong->isChecked == 6): ?>
                                    <option value="6" selected>Hủy đơn đặt phòng</option>
                                    <?php endif; ?>
                                </select>


                            </td>
                        </tr>

                        <tr>
                            <td>
                                <input type="submit" class="btn btn-success btn-sm" value="Cập nhật">
                            </td>
                        </tr>
                    </table>
                </form>
            </div>
        </div>
    </div>

</div>
<!-- /.container-fluid -->

<!-- Custom styles for this page -->
<link href="
 vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
<!-- Page level plugins -->
<script src="vendor/datatables/jquery.dataTables.min.js"></script>
<script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

<!-- Page level custom scripts -->
<script src="js/demo/datatables-demo.js"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutKS', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\testproject\resources\views/dondatphong/edit.blade.php ENDPATH**/ ?>