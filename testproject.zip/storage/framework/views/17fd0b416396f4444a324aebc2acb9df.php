
<?php $__env->startSection('content'); ?>
<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Thêm khách sạn
                <a href="<?php echo e(url('/admin/khachsan')); ?>" class="float-right btn-primary btn-sm">Tất cả</a>
            </h6>
        </div>
        <div class="card-body">
            <?php if(Session:: has('success')): ?>
            <p class="text-success"><?php echo e(session('success')); ?></p>
            <?php endif; ?>
            <div class="table-responsive">
                <form action="<?php echo e(url('/admin/khachsan/')); ?>" method="GET">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('put'); ?>
                    <table class="table table-bordered">
                        <tr>
                            <th>Tên khách sạn</th>
                            <td><input type="text" name="TenTP" class="form-control"></td>
                        </tr>
                        <tr>
                            <th>Địa chỉ</th>
                            <td><input type="text" name="TenTP" class="form-control"></td>
                        </tr>
                        <tr>
                            <th>SDT</th>
                            <td><input type="text" name="TenTP" class="form-control"></td>
                        </tr>
                        <tr>
                            <th>Buffet</th>
                            <td><input type="text" name="TenTP" class="form-control"></td>
                        </tr>
                        <tr>
                            <th>Wifi</th>
                            <td><input type="text" name="TenTP" class="form-control"></td>
                        </tr>
                        <tr>
                            <td colspan="2">
                                <input type="submit" class="btn btn-success btn-sm" value="Thêm">
                            </td>
                        </tr>
                    </table>
                </form>
            </div>
        </div>
    </div>

</div>

<!-- /.container-fluid -->
<?php $__env->startSection('script'); ?>
<!-- Custom styles for this page -->
<link href="<?php echo e(asset('vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
<!-- Page level plugins -->
<script src="<?php echo e(asset('vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>

<!-- Page level custom scripts -->
<script src="<?php echo e(asset('js/demo/datatables-demo.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myproject\resources\views/khachsan/create.blade.php ENDPATH**/ ?>