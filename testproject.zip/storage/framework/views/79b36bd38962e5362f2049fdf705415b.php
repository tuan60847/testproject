
<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Tìm kiếm</h1>
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Tìm kiếm</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <?php if($dondatphongs && count($dondatphongs) > 0): ?>
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Mã đặt phòng</th>
                            <th>Email</th>
                            <th>Ngày đặt phòng</th>
                            <th>Tiền cọc</th>
                            <th>Tổng tiền</th>
                            <th>Trạng thái</th>
                            <th>Thao tác</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th>Mã đặt phòng</th>
                            <th>Email</th>
                            <th>Ngày đặt phòng</th>
                            <th>Tiền cọc</th>
                            <th>Tổng tiền</th>
                            <th>Trạng thái</th>
                            <th>Thao tác</th>
                        </tr>
                    </tfoot>
                    <tbody>
                        <?php if($dondatphongs ): ?>
                        <?php $__currentLoopData = $dondatphongs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(Str::limit($d->UIDDatPhong, 10)); ?></td>
                            <td><?php echo e($d->EmailKH); ?></td>
                            <td><?php echo e($d->NgayDatPhong); ?></td>
                            <td><?php echo e($d->TienCoc); ?></td>
                            <td><?php echo e(number_format($d->tongtien, 0, ',', '.')); ?></td>
                            <td><?php if($d->isChecked==0): ?> Chưa xác nhận
                                <?php elseif($d->isChecked==1): ?> Đã xác nhận
                                <?php elseif($d->isChecked==3): ?> Khách đã nhận phòng
                                <?php elseif($d->isChecked==5): ?> Đơn đã hoàn thành
                                <?php elseif($d->isChecked==6): ?> Đơn đã bị hủy
                                <?php elseif($d->isChecked==7): ?> Khách sạn hủy phòng
                                <?php endif; ?></td>

                            <td>
                                <a href="<?php echo e(url('adminKS/dondadat/findbyKS/'.$d->UIDDatPhong)); ?>" class="btn btn-info btn-sm"><i class="fa fa-eye"></i></a>
                                <a href="<?php echo e(url('adminKS/dondatphong/'.$d->UIDDatPhong.'/edit')); ?>" class="btn btn-success btn-sm"><i class="fa fa-edit"></i></a>
                                <!-- <a onclick="confirm('Bạn có chắc muốn xóa loại phòng này?')" href="<?php echo e(url('admin/loaiphong/'.$d->UIDLoaiPhong.'/delete')); ?>" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></a> -->
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                </table>
                <?php endif; ?>
            </div>
            <div class="table-responsive">
                <?php if($loaiphongs && count($loaiphongs) > 0): ?>
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Mã loại</th>
                            <th>Tên loại phòng</th>
                            <th>Máy lạnh</th>
                            <th>Số giường</th>
                            <th>Giá phòng</th>
                            <th>Số lượng</th>
                            <th>Hình ảnh</th>
                            <th>Thao tác</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th>Mã loại</th>
                            <th>Tên loại phòng</th>
                            <th>Máy lạnh</th>
                            <th>Số giường</th>
                            <th>Giá phòng</th>
                            <th>Số lượng</th>
                            <th>Hình ảnh</th>
                            <th>Thao tác</th>
                        </tr>
                    </tfoot>
                    <tbody>

                        <?php if($loaiphongs): ?>
                        <?php $__currentLoopData = $loaiphongs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($d->UIDLoaiPhong); ?></td>
                            <td><?php echo e($d->TenLoaiPhong); ?></td>
                            <td><?php echo e($d->isMayLanh); ?></td>
                            <td><?php echo e($d->soGiuong); ?></td>
                            <td><?php echo e($d->Gia); ?></td>
                            <td><?php echo e($d->soLuongPhong); ?></td>
                            <td><?php echo e(count($d->hinhanhloaiphongs)); ?></td>
                            <td>
                                <a href="<?php echo e(url('adminKS/loaiphong/findbyKS/'.$d->UIDLoaiPhong.'/show')); ?>" class="btn btn-info btn-sm"><i class="fa fa-eye"></i></a>
                                <a href="<?php echo e(url('adminKS/loaiphong/findbyKS/'.$d->UIDLoaiPhong.'/edit')); ?>" class="btn btn-success btn-sm"><i class="fa fa-edit"></i></a>

                                <a onclick="confirm('Bạn có chắc muốn xóa loại phòng này?')" href="<?php echo e(url('adminKS/loaiphong/findbyKS/'.$d->UIDKS.'/'.$d->UIDLoaiPhong.'/delete')); ?>" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                </table>
                <?php endif; ?>
            </div>
        </div>
    </div>

</div>

<!-- /.container-fluid -->
<?php $__env->startSection('script'); ?>
<!-- Custom styles for this page -->
<link href="<?php echo e(asset('vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
<!-- Page level plugins -->
<script src="<?php echo e(asset('vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>

<!-- Page level custom scripts -->
<script src="<?php echo e(asset('js/demo/datatables-demo.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutKS', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\testproject\resources\views/searchKS.blade.php ENDPATH**/ ?>