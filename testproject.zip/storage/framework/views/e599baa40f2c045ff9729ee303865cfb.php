
<?php $__env->startSection('content'); ?>
  <!-- Begin Page Content -->
  <div class="container-fluid">

<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Thêm thành phố</h6>
    </div>
    <div class="card-body">
      <?php if(Session::has('success')): ?>
     <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
      <?php endif; ?>
        <div class="table-responsive">
          <form action="<?php echo e(url('/city/'.$data->MaTP)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>
                      <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
              <tr>
                <th>Tên thành phố</th>
                <td><input type="text" value="<?php echo e($data->TenTP); ?>"name="TenTP" class="form-control"></td>
              </tr>
              <tr>
                <th>Mô tả</th>
                <td><textarea name="mota" id="" cols="30" rows="10" class="form-control"><?php echo e($data->mota); ?></textarea></td>
              </tr>
              <tr>
                <td>
                    <input type="submit" class="btn btn-success btn-sm" value="Sửa">
                </td>
              </tr>
            </table>
            </form>
        </div>
    </div>
</div>

</div>
<!-- /.container-fluid -->
<?php $__env->startSection('script'); ?>
 <!-- Custom styles for this page -->
 <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
 <!-- Page level plugins -->
 <script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/datatables-demo.js"></script>
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\testproject\resources\views/thanhpho/editTP.blade.php ENDPATH**/ ?>