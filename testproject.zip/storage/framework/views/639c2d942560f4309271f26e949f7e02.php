
<?php $__env->startSection('content'); ?>
<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Sửa thành phố</h6>
        </div>
        <div class="card-body">
            <?php if($errors->any()): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p class="text-danger"><?php echo e($error); ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <?php if(Session::has('success')): ?>
            <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
            <?php endif; ?>
            <div class="table-responsive">
                <form action="<?php echo e(url('admin/diadiemdulich/'.$data->MaDDDL)); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('put'); ?>
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <tr>
                            <th>Tên địa điểm du lịch</th>
                            <td><input type="text" value="<?php echo e($data->TenDiaDiemDuLich); ?>" name="TenDiaDiemDuLich" class="form-control"></td>
                        </tr>
                        <tr>
                            <th>Địa chỉ</th>
                            <td><input type="text" value="<?php echo e($data->DiaChi); ?>" name="DiaChi" class="form-control"></td>
                        </tr>
                        <tr>
                            <th>Mô tả</th>
                            <td><textarea name="MoTa" id="" cols="30" rows="10" class="form-control"><?php echo e($data->MoTa); ?></textarea></td>
                        </tr>
                        <tr>
                            <th>Thời gian hoạt động</th>
                            <td><input type="text" value="<?php echo e($data->ThoiGianHoatDong); ?>" name="ThoiGianHoatDong" class="form-control"></td>
                        </tr>
                        <tr>
                            <th>Giá vé</th>
                            <td><input type="text" value="<?php echo e($data->GiaTien); ?>" name="GiaTien" class="form-control"></td>
                        </tr>
                        <tr>
                            <th>Mã thành phố</th>
                            <td><input type="text" value="<?php echo e($data->MaTP); ?>" name="MaTP" class="form-control"></td>
                        </tr>
                        <tr>
                            <th>Hình ảnh</th>
                            <td>
                                <table class="table table-bordered mt-3">
                                    <tr>
                                        <input type="file" multiple name="imgs[]">
                                        <?php $__currentLoopData = $data->hinhanhdddls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <td class="imgcol<?php echo e($img->MaDDDL); ?>">
                                            <?php if($img): ?>
                                            <img width="150" height="200" src="<?php echo e(asset('storage/app'.$img->src)); ?>" alt="Image" />
                                            <?php endif; ?>
                                            <p>
                                                <button type="button" onclick="return confirm('Bạn có chắc muốn xóa hình này?')" class="btn btn-danger btn-sm delete-image" data-image-id="<?php echo e($img->MaDDDL); ?>">
                                                    <i class="fa fa-trash"></i>
                                                </button>
                                            </p>
                                        </td>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <input type="submit" class="btn btn-success btn-sm" value="Sửa">
                            </td>
                        </tr>
                    </table>
                </form>
            </div>
        </div>
    </div>

</div>
<!-- /.container-fluid -->
<?php $__env->startSection('script'); ?>
<!-- Custom styles for this page -->
<link href="
 vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
<!-- Page level plugins -->
<script src="vendor/datatables/jquery.dataTables.min.js"></script>
<script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

<!-- Page level custom scripts -->
<script src="js/demo/datatables-demo.js"></script>
<script type="text/javascript">
    $(document).ready(function() {
        $(".delete-image").on('click', function() {
            var _img_id = $(this).attr('data-image-id');
            var _vm = $(this);
            $.ajax({
                url: "<?php echo e(url('admin/imgdiadiemdulich/delete')); ?>/" + _img_id,
                dataType: 'json',
                beforeSend: function() {
                    _vm.addClass('disabled');
                },
                success: function(res) {
                    if (res.bool == true) {
                        $(".imgcol" + _img_id).remove();
                    }
                    _vm.removeClass('disabled');
                }
            });
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myproject\resources\views/diadiemdulich/edit.blade.php ENDPATH**/ ?>