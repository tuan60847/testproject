<?php $__env->startSection('content'); ?>
<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Sửa thông tin tài khoản</h6>
        </div>
        <div class="card-body">
            <?php if($errors->any()): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p class="text-danger"><?php echo e($error); ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <?php if(Session::has('success')): ?>
            <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
            <?php endif; ?>
            <div class="table-responsive">
                <form <?php if(Session::has('cksData')): ?> action="<?php echo e(url('adminKS/profile/findbyKS/'.Session::get('cksData')->ADMINKS)); ?>" <?php endif; ?> method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('put'); ?>
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <tr>
                            <th>Họ và Tên</th>
                            <td>
                                <?php if(isset($data) && !empty($data->HoTen)): ?>
                                <input type="text" value="<?php echo e($data->HoTen); ?>" name="HoTen" class="form-control">
                                <?php else: ?>
                                <input type="text" value="" name="HoTen" class="form-control">
                                <?php endif; ?>
                            </td>

                        </tr>
                        <tr>
                            <th>Email</th>
                            <td>
                                <?php if(isset($data) && !empty($data->HoTen)): ?>
                                <input type="text" value="<?php echo e($data->HoTen); ?>" name="HoTen" class="form-control">
                                <?php else: ?>
                                <input type="text" value="" name="HoTen" class="form-control">
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <th>Ngày sinh</th>
                            <td>
                                <?php if(isset($data) && !empty($data->HoTen)): ?>
                                <input type="text" value="<?php echo e($data->HoTen); ?>" name="HoTen" class="form-control">
                                <?php else: ?>
                                <input type="text" value="" name="HoTen" class="form-control">
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <th>SDT</th>
                            <td>
                                <?php if(isset($data) && !empty($data->HoTen)): ?>
                                <input type="text" value="<?php echo e($data->HoTen); ?>" name="HoTen" class="form-control">
                                <?php else: ?>
                                <input type="text" value="" name="HoTen" class="form-control">
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <th>Mật khẩu cũ</th>
                            <td>
                                <?php if(isset($data) && !empty($data->HoTen)): ?>
                                <input type="text" value="<?php echo e($data->HoTen); ?>" name="HoTen" class="form-control">
                                <?php else: ?>
                                <input type="text" value="" name="HoTen" class="form-control">
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <th>Mật khẩu mới</th>
                            <td>
                                <?php if(isset($data) && !empty($data->HoTen)): ?>
                                <input type="text" value="<?php echo e($data->HoTen); ?>" name="HoTen" class="form-control">
                                <?php else: ?>
                                <input type="text" value="" name="HoTen" class="form-control">
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <input type="submit" class="btn btn-success btn-sm" value="Sửa">
                            </td>
                        </tr>
                    </table>
                </form>
            </div>
        </div>
    </div>

</div>
<!-- /.container-fluid -->
<?php $__env->startSection('script'); ?>
<!-- Custom styles for this page -->
<link href="
 vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
<!-- Page level plugins -->
<script src="vendor/datatables/jquery.dataTables.min.js"></script>
<script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

<!-- Page level custom scripts -->
<script src="js/demo/datatables-demo.js"></script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutKS', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\testproject\resources\views/chukhachsan/profile.blade.php ENDPATH**/ ?>