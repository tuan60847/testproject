
<?php $__env->startSection('content'); ?>
<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Thêm loại phòng
                <a <?php if(Session::has('cksData')): ?> href="<?php echo e(url('/adminKS/loaiphong/findbyKS/'. Session::get('cksData')->ADMINKS)); ?>" <?php endif; ?> class="float-right btn-primary btn-sm">Tất cả</a>
            </h6>
        </div>
        <div class="card-body">
            <?php if($errors->any()): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p class="text-danger"><?php echo e($error); ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <?php if(Session:: has('success')): ?>
            <p class="text-success"><?php echo e(session('success')); ?></p>
            <?php endif; ?>
            <div class="table-responsive">

                <form <?php if(Session::has('cksData')): ?> action="<?php echo e(url('/adminKS/loaiphong/findbyKS/'.Session::get('cksData')->ADMINKS.'/')); ?>" <?php endif; ?> method="POST" enctype="multipart/form-data">

                    <?php echo csrf_field(); ?>
                    <table class="table table-bordered">
                        <tr>
                            <th>Tên loại phòng</th>
                            <td><input type="text" name="TenLoaiPhong" class="form-control"></td>
                        </tr>
                        <tr>
                            <th>Máy lạnh</th>
                            <td><input type="text" name="isMayLanh" class="form-control"></td>
                        </tr>
                        <tr>
                            <th>Số giường</th>
                            <td><input type="text" name="soGiuong" class="form-control"></td>
                        </tr>
                        <tr>
                            <th>Giá phòng</th>
                            <td><input type="text" name="Gia" class="form-control"></td>
                        </tr>
                        <tr>
                            <th>Số lượng</th>
                            <td><input type="text" name="soLuongPhong" class="form-control"></td>
                        </tr>
                        <tr>
                            <th>Hình loại phòng</th>
                            <td><input type="file" multiple name="image[]"></td>
                        </tr>
                        <tr>
                            <td colspan="2">
                                <input type="submit" class="btn btn-success btn-sm" value="Thêm">
                            </td>
                        </tr>
                    </table>
                </form>
            </div>
        </div>
    </div>

</div>

<!-- /.container-fluid -->
<?php $__env->startSection('script'); ?>
<!-- Custom styles for this page -->
<link href="<?php echo e(asset('vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
<!-- Page level plugins -->
<script src="<?php echo e(asset('vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>

<!-- Page level custom scripts -->
<script src="<?php echo e(asset('js/demo/datatables-demo.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutKS', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\testproject\resources\views/loaiphong/create.blade.php ENDPATH**/ ?>