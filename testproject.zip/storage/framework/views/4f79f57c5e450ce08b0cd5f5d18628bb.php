
<?php $__env->startSection('content'); ?>
<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Xem loại phòng
                <a <?php if(Session::has('cksData')): ?> href="<?php echo e(url('/adminKS/loaiphong/findbyKS/'. Session::get('cksData')->ADMINKS)); ?>" <?php endif; ?> class="float-right btn-primary btn-sm">Tất cả</a>
            </h6>
        </div>
        <div class="card-body">
            <?php if($errors->any()): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p class="text-danger"><?php echo e($error); ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <?php if(Session:: has('success')): ?>
            <p class="text-success"><?php echo e(session('success')); ?></p>
            <?php endif; ?>
            <div class="table-responsive">
                <form action="<?php echo e(url('/adminKS/loaiphong/findbyKS/'.$loaiphong->UIDLoaiPhong)); ?>" method="GET" enctype="multipart/form-data">

                    <?php echo csrf_field(); ?>
                    <table class="table table-bordered">
                        <tr>
                            <th>Tên loại phòng</th>
                            <td><?php echo e($loaiphong->TenLoaiPhong); ?></td>
                        </tr>
                        <tr>
                            <th>Máy lạnh</th>
                            <td><?php echo e($loaiphong->isMayLanh); ?></td>
                        </tr>
                        <tr>
                            <th>Số giường</th>
                            <td><?php echo e($loaiphong->soGiuong); ?></td>
                        </tr>
                        <tr>
                            <th>Giá phòng</th>
                            <td><?php echo e($loaiphong->Gia); ?></td>
                        </tr>
                        <tr>
                            <th>Số lượng</th>
                            <td><?php echo e($loaiphong->soLuongPhong); ?></td>
                        </tr>
                        <tr>
                            <th>Hình ảnh</th>
                            <td>
                                <table class="table table-bordered mt-3">
                                    <tr>
                                        <?php $__currentLoopData = $loaiphong->hinhanhloaiphongs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <td class="imgcol<?php echo e(asset($img->src)); ?>">
                                            <img width="150" height="200" src="<?php echo e(asset('/image/'.$img->src)); ?>" />
                                        </td>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                    </table>
                </form>
            </div>
        </div>
    </div>

</div>

<!-- /.container-fluid -->
<?php $__env->startSection('script'); ?>
<!-- Custom styles for this page -->
<link href="<?php echo e(asset('vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
<!-- Page level plugins -->
<script src="<?php echo e(asset('vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>

<!-- Page level custom scripts -->
<script src="<?php echo e(asset('js/demo/datatables-demo.js')); ?>"></script>
<script type="text/javascript">
    $(document).ready(function() {
        $(".delete-image").on('click', function() {
            var _img_id = $(this).attr('data-image-id');
            var _vm = $(this);
            $.ajax({
                url: "<?php echo e(url('adminKS/imgloaiphong/delete')); ?>/" + _img_id,
                dataType: 'json',
                beforeSend: function() {
                    _vm.addClass('disabled');
                },
                success: function(res) {
                    if (res.bool == true) {
                        $(".imgcol" + _img_id).remove();
                    }
                    _vm.removeClass('disabled');
                }
            });
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutKS', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\testproject\resources\views/loaiphong/show.blade.php ENDPATH**/ ?>